const CACHE='braff-central-v146-instagram1';
const CORE=['./','./index.html','./braff-export.js','./migration.html','./braff-migration.js','./campeoes-premium.html','./fonts/braff-display.ttf','./fonts/braff-text.ttf','./vision-cpu/tf.min.js','./vision-cpu/blazeface.umd.js','./vision-cpu/model.json','./vision-cpu/group1-shard1of1','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('braff-central-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('message',event=>{if(event.data==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('fetch',event=>{
 const req=event.request,url=new URL(req.url);
 if(req.method!=='GET'||url.origin!==self.location.origin)return;
 if(req.mode==='navigate'||url.pathname.endsWith('.html')||url.pathname.endsWith('.webmanifest')){
  event.respondWith(fetch(req).then(res=>{if(res.ok){const copy=res.clone();event.waitUntil(caches.open(CACHE).then(c=>c.put(req,copy)))}return res}).catch(async()=>{const match=await caches.match(req,{ignoreSearch:true});return match||((url.pathname.endsWith('/')||url.pathname.endsWith('/index.html'))?caches.match('./index.html'):Response.error())}));return;
 }
 event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{if(res.ok)event.waitUntil(caches.open(CACHE).then(c=>c.put(req,res.clone())));return res})));
});
